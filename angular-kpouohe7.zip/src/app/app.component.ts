import { Component } from '@angular/core';

@Component({
  selector: 'my-app',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  name = 'Angular Seat Booking App';

  // Seat configuration
  rows = 12;
  seatsPerRow = [7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 3]; // 11 rows of 7 and 1 row of 3
  seatMap: { seatId: string; status: string }[][] = [];

  constructor() {
    this.initializeSeats();
  }

  // Initialize seats
  initializeSeats() {
    for (let i = 0; i < this.rows; i++) {
      const rowSeats = [];
      for (let j = 1; j <= this.seatsPerRow[i]; j++) {
        rowSeats.push({ seatId: `${i + 1}-${j}`, status: 'Available' });
      }
      this.seatMap.push(rowSeats);
    }
  }

  // Book seats based on user input
  bookSeats(seatCount: number) {
    if (seatCount < 1 || seatCount > 7) {
      alert('You can only book between 1 and 7 seats.');
      return;
    }

    const bookedSeats = [];
    // Priority booking: in a single row
    for (const row of this.seatMap) {
      const availableSeats = row.filter(seat => seat.status === 'Available');
      if (availableSeats.length >= seatCount) {
        for (let i = 0; i < seatCount; i++) {
          availableSeats[i].status = 'Booked';
          bookedSeats.push(availableSeats[i].seatId);
        }
        alert(`Booked Seats: ${bookedSeats.join(', ')}`);
        return;
      }
    }

    // Secondary booking: nearby seats
    for (const row of this.seatMap) {
      const availableSeats = row.filter(seat => seat.status === 'Available');
      for (const seat of availableSeats) {
        if (bookedSeats.length < seatCount) {
          seat.status = 'Booked';
          bookedSeats.push(seat.seatId);
        }
      }
      if (bookedSeats.length === seatCount) {
        alert(`Booked Seats: ${bookedSeats.join(', ')}`);
        return;
      }
    }

    alert('Not enough seats available.');
  }
}
